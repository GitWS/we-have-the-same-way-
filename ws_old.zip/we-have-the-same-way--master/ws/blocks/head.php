<title>Главная</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script type="text/javascript" src="./script/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="./script/auth.js"></script>
<script type="text/javascript" src="./script/reg.js"></script>
<script type="text/javascript" src="./script/relog.js"></script>