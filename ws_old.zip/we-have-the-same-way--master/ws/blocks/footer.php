<footer>
	Сайт разработан командой WorldSkills из ККМТ. © <?php echo date("Y") ?>
</footer>